def saludar():
	print("hola desde la función saludar pertenecient al modulo saludos.py")

class Saludo():
	def __init__(self):
		print("Hola desde el init de la clase saludo del modulo saludos.py")