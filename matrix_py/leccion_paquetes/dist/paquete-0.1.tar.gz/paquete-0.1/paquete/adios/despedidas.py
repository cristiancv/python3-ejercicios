def despedirse():
	print("Adios desde la función despedirse del modulo despedidas.py")

class Despedida():
	def __init__(self):
		print("Adios desde el init de la clase Despedida del modulo despedidas.py")