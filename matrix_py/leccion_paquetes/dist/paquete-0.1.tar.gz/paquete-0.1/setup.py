from setuptools import setup
setup(
	name="paquete",
	version="0.1",
	description="Este es un paquete de prueba",
	author="Cristian Cuesta",
	author_email="micorreo@msn.com",
	url="http://misitioc.org",
	scripts=[],
	packages=["paquete","paquete.hola","paquete.adios"]
)
